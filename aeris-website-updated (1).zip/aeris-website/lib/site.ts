// Company and contact details used by the footer and the legal pages.
// Edit these values in one place. Anything starting with "[CONFIRM" still
// needs a real value before launch.

export const site = {
  productName: "AERIS",
  domain: "https://aeris-intelligence.ai",
  companyName: "Sparient Inc.",
  companyUrl: "https://www.sparient.com",
  // Short form used inside sentences.
  companyLocation: "Rancho Cucamonga, California",
  // Full mailing address shown in the footer and contact sections.
  companyStreet: "10722 Arrow Route, Suite 712",
  companyCity: "Rancho Cucamonga, CA 91730",
  companyCountry: "United States",

  // Public email for business inquiries and privacy or legal requests.
  contactEmail: "contact@sparient.com",

  // Date the current versions of the legal pages take effect.
  legalEffectiveDate: "October 1, 2026",
};

export function isPlaceholder(value: string) {
  return value.startsWith("[CONFIRM");
}
