import type { Metadata } from "next";
import Link from "next/link";
import LegalPage from "@/components/LegalPage";
import ContactEmail from "@/components/ContactEmail";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Product Disclaimer",
  description:
    "What AERIS does and does not do. AERIS supports engineering teams and does not certify compliance or replace engineering judgment.",
  alternates: { canonical: "/disclaimer" },
};

export default function DisclaimerPage() {
  return (
    <LegalPage
      title="Product Disclaimer"
      summary="AERIS supports engineering teams working in safety-critical environments. It is an analytical aid. It does not certify compliance, approve engineering work or take the place of qualified engineers."
    >
      <h2>Engineers stay responsible</h2>
      <p>
        Your engineers and your organization remain responsible for all engineering
        decisions, review outcomes, approvals and compliance determinations. AERIS provides
        observations and analysis to help with investigation and review. Any output from
        AERIS should be checked by a qualified person before it is relied on.
      </p>

      <h2>No certification or compliance claims</h2>
      <p>
        AERIS does not certify, approve or declare compliance with any regulation, standard
        or certification requirement. It does not produce certification evidence or act as
        an engineering or certification authority. Using AERIS does not by itself show that
        a product, process or document meets any requirement.
      </p>
      <p>
        {site.companyName} and AERIS are not affiliated with, endorsed by or acting on behalf
        of any aviation authority, government agency or certification body.
      </p>

      <h2>AI output can be wrong</h2>
      <p>
        AERIS uses artificial intelligence. Like any AI system, it can produce output that
        is incomplete, inaccurate or misleading. Governance controls reduce this risk but do
        not remove it.
      </p>

      <h2>Website content</h2>
      <p>
        The descriptions, screenshots and examples on this website are for general
        information. Some show sample data or illustrative scenarios. Features, deployment
        options (including air-gapped operation) and performance depend on the version,
        configuration and environment agreed with each customer. Statements about future
        plans are not commitments.
      </p>

      <h2>Your agreement governs</h2>
      <p>
        The terms of use, warranties and responsibilities for AERIS are set out in the
        written agreement between {site.companyName} and each customer. If anything on this
        website conflicts with that agreement, the agreement applies. See also our{" "}
        <Link href="/terms">Terms of Use</Link>.
      </p>

      <h2>Questions</h2>
      <p>
        Questions about what AERIS does can be sent to <ContactEmail />.
      </p>
    </LegalPage>
  );
}
