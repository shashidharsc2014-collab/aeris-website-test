import type { Metadata } from "next";
import Link from "next/link";
import LegalPage from "@/components/LegalPage";
import ContactEmail from "@/components/ContactEmail";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Terms of Use",
  description: "The terms that apply when you use the AERIS website, operated by Sparient Inc.",
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  return (
    <LegalPage
      title="Terms of Use"
      summary={`These terms apply to your use of the AERIS website at aeris-intelligence.ai, which is operated by ${site.companyName} By using the website, you agree to them. If you do not agree, please do not use the website.`}
    >
      <h2>About this website</h2>
      <p>
        This website gives general information about AERIS, a product of {site.companyName}
        It is not an offer to sell, license or supply anything. Access to the AERIS product
        is provided only under a separate written agreement with Sparient, and that
        agreement governs the product, not these terms.
      </p>

      <h2>Using the website</h2>
      <p>You may use this website for lawful business purposes. You agree not to:</p>
      <ul>
        <li>use the website in a way that breaks any law or regulation;</li>
        <li>try to gain unauthorized access to the website or the systems behind it;</li>
        <li>interfere with the website, for example by introducing malware or overloading it;</li>
        <li>scrape or copy the website in bulk, or use its content to train AI models, without our written permission;</li>
        <li>send false, misleading or unlawful content through the contact form.</li>
      </ul>

      <h2>Information you send us</h2>
      <p>
        Do not send confidential, proprietary or export-controlled technical information
        through the website or the contact form. Anything you send this way is not treated
        as confidential unless we have agreed otherwise in writing. Our{" "}
        <Link href="/privacy">Privacy Policy</Link> explains how we handle personal
        information.
      </p>

      <h2>Intellectual property</h2>
      <p>
        The website and its content, including text, images, screenshots, graphics and the
        AERIS name and logo, belong to {site.companyName} or its licensors and are protected
        by intellectual property laws. You may view the website and print or save pages for
        your own internal evaluation of AERIS. Any other use needs our written permission.
        See <Link href="/legal">IP and Trademarks</Link> for more.
      </p>

      <h2>Product information</h2>
      <p>
        Descriptions, screenshots and examples on this website are for general information
        and may show features that vary by deployment, configuration or version. They are
        not a commitment that any feature is available. AERIS supports engineering teams and
        does not certify compliance or replace engineering judgment. Please read the{" "}
        <Link href="/disclaimer">Product Disclaimer</Link>.
      </p>

      <h2>Links to other websites</h2>
      <p>
        The website may link to websites run by others, including the {site.companyName}{" "}
        website. We are not responsible for the content or practices of third-party
        websites.
      </p>

      <h2>No warranties</h2>
      <p>
        The website is provided &quot;as is&quot; and &quot;as available&quot;. To the
        fullest extent the law allows, we make no warranties of any kind about the website
        or its content, including warranties of accuracy, merchantability, fitness for a
        particular purpose or non-infringement. We do not promise that the website will be
        uninterrupted or error-free.
      </p>

      <h2>Limitation of liability</h2>
      <p>
        To the fullest extent the law allows, {site.companyName} will not be liable for any
        indirect, incidental, special, consequential or punitive damages, or for any loss of
        data, profits or business, arising from your use of the website or reliance on its
        content. Some jurisdictions do not allow these limits, so they may not fully apply
        to you.
      </p>

      <h2>Indemnity</h2>
      <p>
        You agree to compensate {site.companyName} for claims, losses and reasonable costs
        that arise from your breach of these terms or your misuse of the website.
      </p>

      <h2>Governing law</h2>
      <p>
        These terms are governed by the laws of the State of California, without regard to
        its conflict of law rules. Any dispute about these terms or the website will be
        handled by the state or federal courts located in San Bernardino County, California, and
        you agree to their jurisdiction.
      </p>

      <h2>Changes to these terms</h2>
      <p>
        We may update these terms from time to time. The effective date at the top of the
        page shows when they last changed. Continuing to use the website after a change
        means you accept the updated terms.
      </p>

      <h2>Contact us</h2>
      <p>
        Questions about these terms can be sent to <ContactEmail />.
      </p>
    </LegalPage>
  );
}
