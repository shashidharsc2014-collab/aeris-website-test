import type { Metadata } from "next";
import Link from "next/link";
import LegalPage from "@/components/LegalPage";
import ContactEmail from "@/components/ContactEmail";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  title: "IP and Trademarks",
  description: "Ownership of AERIS, its trademarks and the content on this website.",
  alternates: { canonical: "/legal" },
};

export default function LegalNoticePage() {
  return (
    <LegalPage
      title="IP and Trademarks"
      summary={`AERIS is a product of ${site.companyName} This notice sets out who owns the AERIS name, the AERIS software and the content on this website.`}
    >
      <h2>Ownership</h2>
      <p>
        AERIS, including its software, architecture, documentation and related materials, is
        owned by {site.companyName} and protected by copyright, trade secret and other
        intellectual property laws. Nothing on this website grants a license to use AERIS.
        Product access is available only under a written agreement with Sparient.
      </p>

      <h2>Trademarks</h2>
      <p>
        AERIS and the AERIS logo are trademarks of {site.companyName} You may not use them
        in a way that suggests a connection with, or endorsement by, Sparient without our
        written permission.
      </p>
      <p>
        Other names, logos and trademarks mentioned on this website belong to their
        respective owners. Mentioning them does not mean those owners endorse or are
        affiliated with AERIS or Sparient.
      </p>

      <h2>Website content</h2>
      <p>
        The text, images, screenshots, graphics and layout of this website are copyright
        {" "}{site.companyName} or its licensors. You may view and save pages for your own
        internal evaluation of AERIS. Please contact us before reproducing, publishing or
        adapting any of it. The <Link href="/terms">Terms of Use</Link> explain what else
        is permitted.
      </p>

      <h2>Reporting infringement</h2>
      <p>
        If you believe content on this website infringes your intellectual property, email{" "}
        <ContactEmail /> with a description of the work, where it appears on this website
        and your contact details.
      </p>

      <h2>Permission requests</h2>
      <p>
        To ask about using the AERIS name, logo or website content, email <ContactEmail />.
      </p>
    </LegalPage>
  );
}
