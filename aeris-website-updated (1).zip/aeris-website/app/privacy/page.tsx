import type { Metadata } from "next";
import Link from "next/link";
import LegalPage from "@/components/LegalPage";
import ContactEmail from "@/components/ContactEmail";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description:
    "How Sparient Inc. collects, uses and protects personal information on the AERIS website.",
  alternates: { canonical: "/privacy" },
};

export default function PrivacyPage() {
  return (
    <LegalPage
      title="Privacy Policy"
      summary={`This policy explains what personal information ${site.companyName} collects through the AERIS website at aeris-intelligence.ai, why we collect it and the choices you have.`}
    >
      <h2>Who we are</h2>
      <p>
        AERIS is a product of {site.companyName}, based in {site.companyLocation}. In this
        policy, &quot;Sparient&quot;, &quot;we&quot; and &quot;us&quot; refer to{" "}
        {site.companyName}, which is responsible for the personal information collected
        through this website.
      </p>
      <p>
        This policy covers the website only. Engineering data processed by AERIS in a
        customer deployment is governed by the agreement between Sparient and that customer,
        not by this policy.
      </p>

      <h2>Information we collect</h2>
      <h3>Information you give us</h3>
      <p>
        When you use the Request Discussion form, we collect your name, your organization,
        your business email address and the message you write. If you email us directly, we
        receive your email address and whatever you include in your message.
      </p>
      <p>
        Please do not send confidential, proprietary or export-controlled technical
        information through the form or by email. We will ask for anything we need through
        an appropriate channel.
      </p>

      <h3>Information collected automatically</h3>
      <p>
        Our hosting provider records standard technical information when you visit, such as
        your IP address, browser type, the pages requested and the date and time of each
        request. This information is used to deliver the website and keep it secure.
      </p>
      <p>
        The website does not currently use analytics tools, advertising cookies or tracking
        pixels. Our <Link href="/cookies">Cookie Notice</Link> has more detail.
      </p>

      <h2>How we use your information</h2>
      <ul>
        <li>To reply to your inquiry and discuss whether AERIS fits your needs.</li>
        <li>To manage our business relationship with you and your organization.</li>
        <li>To operate, secure and fix problems with the website.</li>
        <li>To meet our legal obligations and protect our legal rights.</li>
      </ul>
      <p>
        We do not sell your personal information, and we do not share it for cross-context
        behavioral advertising.
      </p>

      <h2>Who we share it with</h2>
      <p>
        We share personal information only with service providers that help us run the
        website and respond to you, and only for those purposes:
      </p>
      <ul>
        <li>Netlify, which hosts the website.</li>
        <li>Google, whose email service delivers form submissions to our team.</li>
      </ul>
      <p>
        We may also disclose information if the law requires it, to protect our rights or
        the safety of others, or as part of a merger, acquisition or sale of assets.
      </p>

      <h2>How long we keep it</h2>
      <p>
        We keep inquiry information for as long as we need it to respond to you and manage
        any business relationship that follows, or longer where the law requires. Hosting
        logs are kept for a limited period set by our hosting provider.
      </p>

      <h2>Your rights</h2>
      <p>
        Depending on where you live, you may have the right to ask what personal information
        we hold about you, to get a copy of it, to correct it or to have it deleted. You may
        also have the right to object to or limit certain uses.
      </p>
      <p>
        California residents have rights under the California Consumer Privacy Act,
        including the right to know, delete and correct personal information, the right to
        opt out of its sale or sharing (we do neither) and the right not to be treated
        differently for using these rights. You can use an authorized agent to make a
        request on your behalf.
      </p>
      <p>
        If you are in the European Economic Area or the United Kingdom, we rely on our
        legitimate interest in responding to business inquiries, or on steps you ask us to
        take before entering a contract. You can also complain to your local data protection
        authority.
      </p>
      <p>
        To make a request, email <ContactEmail />. We will need to confirm your identity
        before acting on it.
      </p>

      <h2>Security</h2>
      <p>
        We use reasonable technical and organizational measures to protect personal
        information. No website or email system is completely secure, so we cannot guarantee
        the security of information sent to us.
      </p>

      <h2>International transfers</h2>
      <p>
        We are based in the United States, and our service providers may process information
        in the United States and other countries. Where required, we use appropriate
        safeguards for these transfers.
      </p>

      <h2>Children</h2>
      <p>
        This website is intended for business users. It is not directed to children, and we
        do not knowingly collect personal information from anyone under 16.
      </p>

      <h2>Changes to this policy</h2>
      <p>
        We may update this policy from time to time. The effective date at the top of the
        page shows when it last changed.
      </p>

      <h2>Contact us</h2>
      <p>
        Questions about this policy or your information can be sent to <ContactEmail />, or
        to {site.companyName}, {site.companyStreet}, {site.companyCity},{" "}
        {site.companyCountry}.
      </p>
    </LegalPage>
  );
}
