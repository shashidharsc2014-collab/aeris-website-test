"use client";

import Image from "next/image";
import { motion } from "framer-motion";

import { useState } from "react";
import Link from "next/link";
import SiteFooter from "@/components/SiteFooter";

import AerisPlatform from "../images/AerisEPlatform.jpg";
import SemanticIntelligence from "../images/SemanticIntelligence.jpg";
import Embeddings from "../images/Embeddings.jpg";
import ReqQIF from "../images/ReqQIF.jpg";
import HLTVerification from "../images/HLTVerification.jpg";
import TraceInvestigation from "../images/Trace Investigation.jpg";
import Workspace from "../images/Workspace.jpg";
import Consumer_AI from "../images/Consumer_AI.jpg";
import Governed_Cognition from "../images/Governed_Cognition.jpg";
import Human_Brain from "../images/Human_Brain.jpg";
import Aeris_Intelligence from "../images/Aeris_Intelligence.jpg";
import Aeris_Logo from "../images/AERIS_Logo.jpg";




{/* Styles*/}

const styles = {
  eyebrow:
    "uppercase tracking-[0.3em] text-blue-600",

  sectionTitle:
    "text-4xl md:text-5xl font-semibold leading-tight",

  heroTitle:
    "text-6xl md:text-7xl font-semibold leading-[0.95] tracking-tight",

  body:
    "text-lg md:text-xl text-slate-600 leading-relaxed",

  bodyDark:
    "text-lg md:text-xl text-slate-300 leading-relaxed",

  cardTitle:
    "text-2xl font-semibold",
};


export default function Home() {

const [loading, setLoading] = useState(false);
const [submitted, setSubmitted] = useState(false);	

const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

const [formData, setFormData] = useState({
  name: "",
  organization: "",
  email: "",
  message: "",
});

/*Submit handler*/
const handleSubmit = async (
  e: React.FormEvent
) => {
  e.preventDefault();

  setLoading(true);

  try {
    const response = await fetch(
      "/api/contact",
      {
        method: "POST",
        headers: {
          "Content-Type":
            "application/json",
        },
        body: JSON.stringify(formData),
      }
    );

    if (response.ok) {
      setSubmitted(true);

      setFormData({
        name: "",
        organization: "",
        email: "",
        message: "",
      });
    }
  } catch (err) {
    console.error(err);
  }

  setLoading(false);
};

	/* FAQs*/
	const [openFaq, setOpenFaq] = useState<number | null>(null);

const faqs = [

{
question:
"Who remains responsible for engineering decisions?",
answer:
"Engineers remain responsible for all engineering decisions, review dispositions, approvals and compliance determinations. AERIS provides investigative observations and analytical support but does not act as an engineering authority."
},

{
question:
"Does using AERIS create certification risk?",
answer:
"AERIS is designed to support engineering review activities without creating certification artefacts, asserting compliance or replacing human engineering judgement. Governance boundaries are enforced as a core architectural principle."
},

{
question:
"Can AERIS operate in air-gapped environments?",
answer:
"Yes. AERIS supports enterprise-controlled deployment models including isolated networks, local infrastructure and fully air-gapped environments. Engineering data remains under organizational control."
},

{
question:
"Is engineering data used to train AI models?",
answer:
"No. Engineering data remains under customer ownership and control. AERIS is designed for enterprise deployment where organizational data is not used to train public AI models."
},

{
question:
"Can AERIS generate requirements, code or certification artefacts?",
answer:
"No. AERIS is intentionally constrained from authoring lifecycle artefacts, certification evidence or compliance declarations. Its role is to assist investigation and review activities while preserving human authority."
},

{
question:
"What makes AERIS different from generic AI platforms?",
answer:
"AERIS combines engineering understanding, lifecycle-aware investigation, governed intelligence and enterprise deployment controls within a platform specifically designed for safety-critical engineering environments."
}

];


	
  return (
  
  
    <>
    <main className="bg-white text-slate-900 pt-20">
	
		{/* Top Menu */}
		
	<header
	  className="
	  fixed
	  top-0
	  left-0
	  right-0
	  z-50
	  bg-white/90
	  backdrop-blur-xl
	  border-b
	  border-slate-200
	  "
	>

	  <div className="max-w-7xl mx-auto px-8">

		<div className="h-20 flex items-center">

		{/* LOGO */}

		<a
		  href="#home"
		  className="flex flex-col leading-none"
		>
		  <span className="text-2xl font-semibold tracking-wide">
			AERIS
		  </span>

		  <span className="text-xs text-slate-500 tracking-[0.15em] mt-1">
			Governed Intelligence System
		  </span>
		</a>
				  

		  {/* RIGHT SIDE */}

		  <div className="ml-auto flex items-center gap-12">

			<button
			  className="md:hidden text-3xl text-slate-700"
			  onClick={() =>
				setMobileMenuOpen(!mobileMenuOpen)
			  }
			>
			  ☰
			</button>
			
			<nav className="hidden md:flex items-center gap-10">

			  <a
				href="#platform"
				className="text-slate-700 hover:text-blue-600 transition"
			  >
				Platform
			  </a>

			  <a
				href="#capabilities"
				className="text-slate-700 hover:text-blue-600 transition"
			  >
				Capabilities
			  </a>

			  <a
				href="#outcomes"
				className="text-slate-700 hover:text-blue-600 transition"
			  >
				Outcomes
			  </a>
			  
			  <a
				href="#faq"
				className="text-slate-700 hover:text-blue-600 transition"
			  >
				FAQs
			  </a>

			  <a
				href="#why-aeris"
				className="text-slate-700 hover:text-blue-600 transition"
			  >
				Why AERIS
			  </a>

			</nav>

			<a
			  href="#explore"
			  className="
			  hidden md:block
			  px-6
			  py-3
			  rounded-full
			  bg-blue-600
			  text-white
			  font-medium
			  hover:bg-blue-700
			  transition
			  "
			>
			  Explore AERIS
			</a>

		  </div>

		</div>
		
		{mobileMenuOpen && (
			  <div className="md:hidden border-t border-slate-200 bg-white">

				<nav className="flex flex-col p-6 gap-4">

				  <a
					href="#platform"
					onClick={() => setMobileMenuOpen(false)}
					className="text-slate-700"
				  >
					Platform
				  </a>

				  <a
					href="#capabilities"
					onClick={() => setMobileMenuOpen(false)}
					className="text-slate-700"
				  >
					Capabilities
				  </a>

				  <a
					href="#outcomes"
					onClick={() => setMobileMenuOpen(false)}
					className="text-slate-700"
				  >
					Outcomes
				  </a>

				  <a
					href="#faq"
					onClick={() => setMobileMenuOpen(false)}
					className="text-slate-700"
				  >
					FAQs
				  </a>

				  <a
					href="#why-aeris"
					onClick={() => setMobileMenuOpen(false)}
					className="text-slate-700"
				  >
					Why AERIS
				  </a>
				  
				  <a
					  href="#explore"
					  onClick={() => setMobileMenuOpen(false)}
					  className="
						mt-4
						px-5
						py-3
						rounded-full
						bg-blue-600
						text-white
						text-center
					  "
					>
					  Explore AERIS
					</a>

				</nav>

			  </div>
			)}

	  </div>

	</header>

  {/* HERO */}
  <section id="home" className="min-h-screen flex items-center">
    <div className="max-w-7xl mx-auto px-8 w-full"> 
	{/*
      <div className="text-sm uppercase tracking-[0.35em] text-blue-600 font-medium mb-10">
        AERIS
      </div>
*/}
      <div className="grid lg:grid-cols-[1.2fr_0.8fr] gap-20 items-center">

        <div>

          <h1 className={styles.heroTitle}>
            Adopt AI
            <br />
            Without Surrendering
            <br />
            Engineering Control.
          </h1>

          <p className="mt-10 text-xl text-slate-600 max-w-2xl leading-relaxed">
            Adopt AI within safety-critical engineering programs through 
			governance, human authority preservation, 
			and enterprise-controlled deployment.
          </p>
		  {/*
          <div className="mt-12 flex flex-wrap gap-4">

            <button className="px-8 py-4 bg-blue-600 text-white rounded-full font-medium hover:bg-blue-700 transition">
              Explore AERIS
            </button>

            <button className="px-8 py-4 border border-slate-300 rounded-full hover:bg-slate-50 transition">
              View Platform
            </button>

          </div>
          */}
        </div>

        <div>

          <div className="rounded-[32px] border border-slate-200 bg-slate-50 p-10 shadow-sm">

            <div className="text-sm uppercase tracking-[0.25em] text-slate-400 mb-8">
              The AI Adoption Challenge
            </div>

            <div className="space-y-6">

              <div className="flex justify-between">
                <span>Can AI Be Governed?</span>
                <span>?</span>
              </div>

              <div className="flex justify-between">
                <span>Who Remains Accountable?</span>
                <span>?</span>
              </div>

              <div className="flex justify-between">
                <span>Where Does The Data Go?</span>
                <span>?</span>
              </div>

              <div className="flex justify-between">
                <span>Is it Audit Safe?</span>
                <span>?</span>
              </div>

              <div className="flex justify-between">
                <span>Can It Operate Air-Gapped?</span>
                <span>?</span>
              </div>

            </div>

          </div>

        </div>

      </div>
    </div>
  </section>

 {/* THE PARADIGM SHIFT */}

	<section className="min-h-screen flex items-center bg-grey">

	  <div className="max-w-7xl mx-auto px-6 w-full">


	{/* Header */}

	<div className="text-center max-w-5xl mx-auto">

	  <div className={`${styles.eyebrow} text-blue-400 mb-6`}>
		THE PARADIGM SHIFT
	  </div>

	  <h2 className={styles.sectionTitle}>
		The Future Is Not Just AI.
		<br />
		It Is Governed Intelligence.
	  </h2>

	  <p className={`mt-3 ${styles.body} max-w-1xl mx-auto`}>
		Safety-critical engineering requires more than analytical capability.
		It requires governance, accountability, traceability and preserved
		human authority.
	  </p>

	</div>

	{/* Visual Comparison */}

	<div className="mt-8 grid lg:grid-cols-2 gap-8 items-start">

	  <div className="rounded-3xl overflow-hidden shadow-xl">
		<Image
		  src={Consumer_AI}
		  alt="Consumer AI"
		  className="w-full object-contain"
		/>
	  </div>

	  <div className="rounded-3xl overflow-hidden shadow-2xl border border-slate-200">
		<Image
		  src={Governed_Cognition}
		  alt="Governed Cognition"
		  className="w-full max-h-[500px] object-contain"
		/>
	  </div>

	</div>

	  </div>

</section>
 

  {/* Human Authority Model*/}
  
  <section className="relative py-10 overflow-hidden bg-black">
  {/*
  <Image
    src={Human_Brain}
    alt=""
    fill
    className="object-contain scale-75 opacity-25 blur-sm"
  />
  */}
  <div className="absolute inset-0 bg-black/60" />

  <div className="relative z-10 flex items-center justify-center py-20">

    <motion.div
      initial={{ opacity: 0, y: 80 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
      className="text-center text-white"
    >

	   <div className={styles.eyebrow}>
	  Human Authority Preservation Model
	</div>

	<h2 className="text-4xl md:text-6xl font-semibold leading-[0.95]">
	  Human Authority
	  <br />
	  Is Absolute.
	</h2>

	<p className="mt-12 text-2xl text-slate-300 max-w-4xl mx-auto leading-relaxed">
	  AI investigates
	  AI analyzes.
	  AI informs.
	</p>

	<p className="mt-10 text-3xl text-white max-w-4xl mx-auto leading-relaxed">
	  Humans review.
	  Humans decide.
	  Humans remain accountable.
	</p>
	
	
	
	<div className="mt-20 flex items-center justify-center gap-10 flex-wrap">
	
	<motion.div
	  initial={{ opacity: 0, y: 30 }}
	  whileInView={{ opacity: 1, y: 0 }}
	  transition={{ delay: 0.3 }}
	  className="w-64 h-40 rounded-3xl border border-white/10 bg-white/5 backdrop-blur-sm flex flex-col items-center justify-center"
	>
	  <div className="text-5xl mb-4">👤</div>
	  <div className="font-semibold">Human Initiates</div>
	</motion.div>


	<motion.div
	  initial={{ opacity: 0 }}
	  whileInView={{ opacity: 1 }}
	  transition={{ delay: 0.6 }}
	  className="text-blue-400 text-4xl"
	>
	  →
	</motion.div>
	
	
	<motion.div
	  initial={{ opacity: 0, scale: 0.9 }}
	  whileInView={{ opacity: 1, scale: 1 }}
	  transition={{ delay: 1.3 }}
	  className="w-64 h-40 rounded-3xl border border-blue-500/30 bg-blue-500/10 backdrop-blur-sm flex flex-col items-center justify-center"
	>
	  <div className="text-5xl mb-4">⚙</div>
	  <div className="font-semibold">AI Analyzes</div>
	</motion.div>
	
	
	<motion.div
	  initial={{ opacity: 0 }}
	  whileInView={{ opacity: 1 }}
	  transition={{ delay: 1.5 }}
	  className="text-blue-400 text-4xl"
	>
	  →
	</motion.div>
	
	<motion.div
	  initial={{ opacity: 0, y: 30 }}
	  whileInView={{ opacity: 1, y: 0 }}
	  transition={{ delay: 1.7 }}
	  className="w-64 h-40 rounded-3xl border border-white/10 bg-white/5 backdrop-blur-sm flex flex-col items-center justify-center"
	>
	  <div className="text-5xl mb-4">✓</div>
	  <div className="font-semibold">Human Decides</div>
	</motion.div>
	
	</div>


    </motion.div>

  </div>

</section>



  {/* INTRODUCING AERIS */}
  
  {/*
<section className="py-24 bg-slate-50">

    <div className="max-w-6xl mx-auto px-8 text-center">

  <div className="uppercase tracking-[0.35em] text-blue-600 mb-8">
    Introducing AERIS
  </div>
  
    <div className={styles.sectionTitle}>
    Aerospace Engineering Review & Insight System
  </div>

  <h2 className="text-4xl md:text-2xl font-semibold leading-[0.95] max-w-1xl mx-auto">
    Governed Intelligence
    For Safety-Critical
    Engineering.
  </h2>

  <p className="mt-16 text-xl text-slate-600 leading-relaxed max-w-xl mx-auto">
    AERIS enables the adoption of AI within safety-critical engineering programs.
  </p>

  <div className="mt-20 grid md:grid-cols-3 gap-8">

    <div className="p-10 rounded-3xl bg-white shadow-sm">
      <div className="text-blue-600 font-medium mb-4">
        Governance
      </div>

      <p className="text-slate-600">
        AI operating within defined
        engineering boundaries.
      </p>
    </div>

    <div className="p-10 rounded-3xl bg-white shadow-sm">
      <div className="text-blue-600 font-medium mb-4">
        Human Authority
      </div>

      <p className="text-slate-600">
        Human accountability
        remains preserved.
      </p>
    </div>

    <div className="p-10 rounded-3xl bg-white shadow-sm">
      <div className="text-blue-600 font-medium mb-4">
        Enterprise Control
      </div>

      <p className="text-slate-600">
        Deploy within
        enterprise-controlled environments.
      </p>
    </div>

  </div>

</div>

</section>
*/}

{/* INTRODUCING AERIS */}

<section id="aeris" className="min-h-screen flex items-center bg-slate-50">

  <div className="max-w-6xl mx-auto px-8 text-center">

    <div className={`${styles.eyebrow} mb-8`}>
      INTRODUCING AERIS
    </div>

    <h2 className={styles.sectionTitle}>
      Governed Intelligence
      <br />
      For Safety-Critical Engineering.
    </h2>

    <p className="mt-8 text-2xl text-slate-600 max-w-4xl mx-auto leading-relaxed">
      AERIS enables organizations to adopt AI
      without surrendering engineering governance,
      human authority or enterprise control.
    </p>

    <div className="mt-16 grid md:grid-cols-3 gap-8">

      <div className="p-10 rounded-3xl bg-white border border-slate-200">

        <div className="text-4xl mb-6">🛡</div>

        <h3 className="text-xl font-semibold mb-4">
          Governed Operation
        </h3>

        <p className="text-slate-600">
          AI operates within defined engineering
          boundaries and review constraints.
        </p>

      </div>

      <div className="p-10 rounded-3xl bg-white border border-slate-200">

        <div className="text-4xl mb-6">👤</div>

        <h3 className="text-xl font-semibold mb-4">
          Human Authority
        </h3>

        <p className="text-slate-600">
          Human review, decision making and
          accountability remain preserved.
        </p>

      </div>

      <div className="p-10 rounded-3xl bg-white border border-slate-200">

        <div className="text-4xl mb-6">🔒</div>

        <h3 className="text-xl font-semibold mb-4">
          Air-Gapped Deployement
        </h3>

        <p className="text-slate-600">
          Deploy inside enterprise-controlled
          and air-gapped environments.
        </p>

      </div>

    </div>

  </div>

</section>

	{/* THE AERIS PLATFORM */}

	<section id="platform" className="py-32 bg-slate-950 text-white overflow-hidden">

	<motion.div
	initial={{ opacity: 0, y: 80 }}
	whileInView={{ opacity: 1, y: 0 }}
	viewport={{ once: true }}
	transition={{ duration: 0.8 }}
	className="max-w-7xl mx-auto px-8"

	>


<div className="grid lg:grid-cols-2 gap-20 items-center">

  {/* LEFT SIDE */}

  <div>

    <div className="uppercase tracking-[0.3em] text-blue-400 mb-6">
      The AERIS Platform
    </div>

    <h2 className={styles.sectionTitle}>
      Built For Complex Engineering Investigation
    </h2>

    <p className="mt-10 text-xl text-slate-300 leading-relaxed">
      AERIS provides a governed engineering workspace for
	requirements review, verification assessment,
	traceability investigation and cross-artefact analysis
	across the engineering lifecycle.
    </p>
	
	{/* OFFLINE CALLOUT */}
		{/*
	<div className="mt-8 rounded-2xl border border-cyan-500/20 bg-cyan-500/5 p-5 backdrop-blur-sm">

	  <div className="text-cyan-300 font-semibold text-lg mb-2">
		Offline Operation
	  </div>

	  <div className="text-slate-300 leading-relaxed">
		Deploy entirely within your infrastructure,
		including air-gapped and restricted-network
		environments, with no dependency on external
		AI services or internet connectivity.
	  </div>

	</div>
		*/}
		
		
			<div className="mt-10 rounded-3xl border border-cyan-400/30
				bg-cyan-500/10 p-8">

				  <div className="text-cyan-300 text-2xl font-bold mb-3">
					Offline Operation
				  </div>

				  <div className="text-lg text-slate-200 leading-relaxed">
					Deploy entirely within customer infrastructure,
					including air-gapped and restricted-network
					environments.
				  </div>

				  <div className="mt-4 text-cyan-200 font-medium">
					No cloud dependency • No external AI services • No internet required
				  </div>

				</div>
	{/*
    <div className="mt-12 space-y-4">

      <div className="flex items-center gap-3 text-slate-300">
        <span className="text-blue-400">•</span>
        Requirements Review Intelligence
      </div>

      <div className="flex items-center gap-3 text-slate-300">
        <span className="text-blue-400">•</span>
        Verification Assessment Intelligence
      </div>

      <div className="flex items-center gap-3 text-slate-300">
        <span className="text-blue-400">•</span>
        Traceability Investigation
      </div>

      <div className="flex items-center gap-3 text-slate-300">
        <span className="text-blue-400">•</span>
        Cross-Artefact Engineering Analysis
      </div>

    </div>

    <div className="mt-12 inline-block rounded-3xl border border-white/10 bg-white/5 backdrop-blur-xl px-8 py-6">

      <div className="text-sm uppercase tracking-[0.25em] text-slate-400 mb-3">
        Investigation Workspace
      </div>

      <div className="text-lg text-slate-200">
        Requirements • Design • Code • Verification • Traceability
      </div>

    </div>
	*/}
  </div>

  {/* RIGHT SIDE */}

  <motion.div
    whileHover={{ scale: 1.02 }}
    transition={{ duration: 0.3 }}
    className="relative"
  >

    <div className="absolute -inset-6 bg-blue-500/20 blur-3xl rounded-full" />

    <div className="relative rounded-[32px] overflow-hidden border border-white/10 shadow-2xl">

      <Image
        src={AerisPlatform}
        alt="AERIS Platform"
        className="w-full h-auto"
      />

    </div>

  </motion.div>

</div>


</motion.div>

</section>

	
	
  {/* what AERIS Does  */}
  
  {/* 
  <section className="py-16 bg-white">

  <div className="max-w-7xl mx-auto px-8">

    <div className="text-center mb-20">

      <div className="uppercase tracking-[0.3em] text-blue-600 mb-6">
        What AERIS Does
      </div>

      <h2 className={styles.sectionTitle}>
        Review.
        Investigate.
        Understand.
      </h2>

      <p className="mt-8 text-xl text-slate-600 max-w-3xl mx-auto">
        AERIS helps engineering teams review complex artefacts,
        investigate lifecycle relationships and establish
        engineering context before making decisions.
      </p>

    </div>

     <div className="grid lg:grid-cols-3 gap-8">

  <motion.div
    whileHover={{ y: -10, scale: 1.02 }}
    transition={{ duration: 0.2 }}
    className="p-10 rounded-3xl bg-white border border-slate-200 shadow-sm hover:shadow-xl"
  >
    <div className="text-6xl font-light text-blue-100 mb-6">
      01
    </div>

    <h3 className="text-3xl font-semibold mb-6">
      Review
    </h3>

    <p className="text-slate-600 leading-relaxed">
      Surface engineering observations across
      requirements, verification evidence and
      lifecycle artefacts requiring review.
    </p>

    <div className="mt-8 text-blue-600 font-medium">
      Identify review signals
    </div>
  </motion.div>

  <motion.div
    whileHover={{ y: -10, scale: 1.02 }}
    transition={{ duration: 0.2 }}
    className="p-10 rounded-3xl bg-white border border-slate-200 shadow-sm hover:shadow-xl"
  >
    <div className="text-6xl font-light text-blue-100 mb-6">
      02
    </div>

    <h3 className="text-3xl font-semibold mb-6">
      Investigate
    </h3>

    <p className="text-slate-600 leading-relaxed">
      Explore relationships across requirements,
      design, source code, verification evidence
      and traceability data.
    </p>

    <div className="mt-8 text-blue-600 font-medium">
      Follow engineering relationships
    </div>
  </motion.div>

  <motion.div
    whileHover={{ y: -10, scale: 1.02 }}
    transition={{ duration: 0.2 }}
    className="p-10 rounded-3xl bg-white border border-slate-200 shadow-sm hover:shadow-xl"
  >
    <div className="text-6xl font-light text-blue-100 mb-6">
      03
    </div>

    <h3 className="text-3xl font-semibold mb-6">
      Understand
    </h3>

    <p className="text-slate-600 leading-relaxed">
      Establish engineering context before making
      review, investigation and program decisions.
    </p>

    <div className="mt-8 text-blue-600 font-medium">
      Build engineering understanding
    </div>
  </motion.div>

</div>

  </div>

</section>
  */}
  
  {/* HOW AERIS WORKS */}

  
{/* THE AERIS INVESTIGATION MODEL */}

<section id="capabilities" className="py-32 bg-white">

  <div className="max-w-7xl mx-auto px-8">

    {/* HEADER */}

    <div className="text-center mb-12">

      <div className="uppercase tracking-[0.3em] text-blue-600 mb-6">
        The AERIS Investigation Model
      </div>

      <h2 className={styles.sectionTitle}>
        Built Around
        Understanding.
      </h2>

      <p className="mt-8 text-xl text-slate-600 max-w-4xl mx-auto">
        AERIS establishes context, investigates engineering
        relationships, applies governed intelligence and
        produces informed observations for human review.
      </p>

    </div>

    {/* GRID */}

    <div className="grid md:grid-cols-2 gap-2">

      {/* CONTEXT */}

      <motion.div
        whileHover={{ y: -8 }}
        transition={{ duration: 0.25 }}
        className="group"
      >
        <div className="h-full rounded-[32px] border border-slate-200 bg-white p-8 shadow-sm hover:shadow-xl transition-all">

          <div className="text-blue-600 text-sm uppercase tracking-[0.25em] mb-6">
            Foundation
          </div>

          <h3 className="text-3xl font-semibold mb-6">
            Context
          </h3>

          <p className="text-slate-600 text-lg leading-relaxed">
            Engineering questions rarely exist in isolation.
            AERIS establishes relevant engineering context
            before analysis begins.
          </p>

        </div>
      </motion.div>

      {/* INVESTIGATION */}

      <motion.div
        whileHover={{ y: -8 }}
        transition={{ duration: 0.25 }}
        className="group"
      >
        <div className="h-full rounded-[32px] border border-slate-200 bg-white p-8 shadow-sm hover:shadow-xl transition-all">

          <div className="text-blue-600 text-sm uppercase tracking-[0.25em] mb-6">
            Exploration
          </div>

          <h3 className="text-3xl font-semibold mb-6">
            Investigation
          </h3>

          <p className="text-slate-600 text-lg leading-relaxed">
            Relationships, dependencies and engineering
            evidence are explored to establish a deeper
            understanding of the problem.
          </p>

        </div>
      </motion.div>

      {/* GOVERNED INTELLIGENCE */}

      <motion.div
        whileHover={{ y: -8 }}
        transition={{ duration: 0.25 }}
        className="group"
      >
        <div className="h-full rounded-[32px] border border-blue-200 bg-blue-50 p-8 shadow-sm hover:shadow-xl transition-all">

          <div className="text-blue-700 text-sm uppercase tracking-[0.25em] mb-6">
            Analysis
          </div>

          <h3 className="text-3xl font-semibold mb-6">
            Governed
            Intelligence
          </h3>

          <p className="text-slate-700 text-lg leading-relaxed">
            Analysis operates within defined engineering
            boundaries and human authority constraints.
          </p>

        </div>
      </motion.div>

      {/* INFORMED OBSERVATIONS */}

      <motion.div
        whileHover={{ y: -8 }}
        transition={{ duration: 0.25 }}
        className="group"
      >
        <div className="h-full rounded-[32px] border border-green-200 bg-green-50 p-8 shadow-sm hover:shadow-xl transition-all">

          <div className="text-green-700 text-sm uppercase tracking-[0.25em] mb-6">
            Outcome
          </div>

          <h3 className="text-3xl font-semibold mb-6">
            Informed
            Observations
          </h3>

          <p className="text-slate-700 text-lg leading-relaxed">
            Structured observations are produced to support
            engineering review, investigation and human
            decision making.
          </p>

        </div>
      </motion.div>

    </div>

  </div>

</section>  
  
{/* BUILDING ENGINEERING INTELLIGENCE */}

<section className="py-16 bg-white">

  <div className="max-w-7xl mx-auto px-6">

    <motion.div
      initial={{ opacity: 0, y: 60 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.7 }}
      className="text-center max-w-5xl mx-auto mb-16"
    >

      <div className="uppercase tracking-[0.3em] text-blue-600 mb-6">
        Building Engineering Intelligence
      </div>

      <h2 className={styles.sectionTitle}>
        AERIS Understands
        Before It
        Investigates.
      </h2>

      <p className="mt-4 text-xl text-slate-600 leading-relaxed max-w-3xl mx-auto">
	  AERIS establishes engineering context before investigation,
	  creating a structured understanding of relationships across
	  the lifecycle.
      </p>

    </motion.div>

    <div className="grid lg:grid-cols-2 gap-6 items-start">

  <motion.div
    initial={{ opacity: 0, x: -50 }}
    whileInView={{ opacity: 1, x: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 1.0 }}
  >
    <div className="text-sm uppercase tracking-[0.3em] text-blue-600 mb-4">
      Semantic Understanding
    </div>

    <div className="rounded-[32px] overflow-hidden shadow-2xl border border-slate-200">
      <Image
        src={SemanticIntelligence}
        alt="Semantic Intelligence"
        className="w-full h-auto"
      />
    </div>
	{/*
    <p className="mt-4 text-lg text-slate-600">
      Engineering artefacts are transformed into structured
      semantic representations that preserve engineering
      meaning, terminology and context.
    </p>*/}
  </motion.div>

  <motion.div
    initial={{ opacity: 0, x: 50 }}
    whileInView={{ opacity: 1, x: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 1.0}}
  >
    <div className="text-sm uppercase tracking-[0.3em] text-blue-600 mb-4">
      Engineering Intelligence Workspace
    </div>

    <div className="rounded-[32px] overflow-hidden shadow-2xl border border-slate-200">
      <Image
        src={Embeddings}
        alt="Engineering Intelligence Workspace"
        className="w-full h-auto"
      />
    </div>
	{/*
    <p className="mt-4 text-lg text-slate-600">
      Requirements, design, source code, verification and
      traceability become available for governed engineering
      investigation.
    </p>
	
	*/}
  </motion.div>

</div>

		{/* CLOSING STATEMENT */}

		<div className="max-w-4xl mx-auto text-center mt-8">

		  <div className="uppercase tracking-[0.3em] text-blue-600 text-sm mb-4">
			UNDERSTANDING PRECEDES INVESTIGATION
		  </div>

		  <p className="text-xl text-slate-700 leading-relaxed">
			AERIS builds engineering understanding before investigation begins.
		  </p>

		</div>

</div>
</section>
{/*
{ REQUIREMENTS INTELLIGENCE }

<section className="py-32 bg-white">

  <div className="max-w-7xl mx-auto px-8">

    <div className="grid lg:grid-cols-2 gap-20 items-center">

      <motion.div
        initial={{ opacity: 0, x: -80 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
      >

        <div className="uppercase tracking-[0.3em] text-blue-600 mb-4">
          Review Intelligence
        </div>

        <h2 className={styles.sectionTitle}>
          Identify What
          Requires Human
          Attention.
        </h2>

        <p className="mt-10 text-xl text-slate-600">
          Surface ambiguity, consistency concerns,
          testability risks, derived requirement signals
          and review observations for engineering assessment.
        </p>

      </motion.div>

      <motion.div
        initial={{ opacity: 0, x: 80 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="rounded-[32px] overflow-hidden shadow-2xl"
      >

        <Image
          src={ReqQIF}
          alt="Requirements Intelligence"
          className="w-full h-auto"
        />

      </motion.div>

    </div>

  </div>

</section>


{ VERIFICATION }

<section className="py-16 bg-slate-950 text-white">

  <div className="max-w-7xl mx-auto px-8">

    <div className="grid lg:grid-cols-2 gap-20 items-center">

      <motion.div
        initial={{ opacity: 0, x: -80 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="order-2 lg:order-1 rounded-[32px] overflow-hidden shadow-2xl border border-white/10"
      >

        <Image
          src={HLTVerification}
          alt="Verification Intelligence"
          className="w-full h-auto"
        />

      </motion.div>

      <motion.div
        initial={{ opacity: 0, x: 80 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="order-1 lg:order-2"
      >

        <div className="uppercase tracking-[0.3em] text-blue-400 mb-6">
          Verification Intelligence
        </div>

        <h2 className={styles.sectionTitle}>
          Verification Evidence
          In Engineering
          Context.
        </h2>

        <p className="mt-10 text-xl text-slate-300">
          Analyze verification evidence,
          expected behaviour and engineering
          observations within a governed
          investigation workflow.
        </p>

      </motion.div>

    </div>

  </div>

</section>


{ TRACE INVESTIGATION }

<section className="py-24 bg-slate-950 text-white">

  <div className="max-w-7xl mx-auto px-8">

    <motion.div
      initial={{ opacity: 0, y: 80 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
      className="text-center mb-20"
    >

      <div className="uppercase tracking-[0.3em] text-blue-400 mb-6">
        Cross-Artefact Investigation
      </div>

	<h2 className={styles.sectionTitle}>
	  Engineering Questions
	  Across The Entire
	  Lifecycle.
	</h2>

      <p className="mt-10 text-xl text-slate-400 max-w-4xl mx-auto">
        Investigated as a connected engineering system.
      </p>

    </motion.div>

    <motion.div
      whileHover={{ scale: 1.02 }}
      className="rounded-[32px] overflow-hidden shadow-2xl"
    >
      <Image
        src={TraceInvestigation}
        alt=""
        className="w-full h-auto"
      />
    </motion.div>

  </div>

</section>

*/}

{/* ENGINEERING WORKSPACE */}

<section className="min-h-screen flex items-center bg-slate-950 text-white">

  <div className="max-w-7xl mx-auto px-8">

    <div className="grid lg:grid-cols-[45%_55%] gap-20 items-center">

      {/* LEFT SIDE */}

      <motion.div
        initial={{ opacity: 0, x: -50 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
      >

        <div className="uppercase tracking-[0.3em] text-blue-400 mb-6">
          Governed Engineering Workspace
        </div>

        <h2 className={styles.sectionTitle}>
          A Unified Environment
			For Engineering Intelligence.
        </h2>

        <p className="mt-8 text-xl text-slate-300 leading-relaxed">
			Bringing engineering knowledge together across the lifecycle.
        </p>

        <p className="mt-8 text-xl text-slate-400 leading-relaxed">
          Investigated within a governed engineering
          workspace designed for safety-critical programs.
        </p>

        <div className="mt-12 flex flex-wrap gap-4">

          <div className="px-5 py-3 rounded-full bg-white/10 border border-white/10">
            Enterprise Platform
          </div>

          <div className="px-5 py-3 rounded-full bg-white/10 border border-white/10">
            Lifecycle-Aware Context
          </div>

          <div className="px-5 py-3 rounded-full bg-white/10 border border-white/10">
            Governed Investigation
          </div>

        </div>

      </motion.div>

      {/* RIGHT SIDE */}

      <motion.div
        initial={{ opacity: 0, x: 50 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
        whileHover={{ scale: 1.02 }}
      >

        <div className="rounded-[32px] overflow-hidden shadow-2xl border border-white/10">

          <Image
            src={Workspace}
            alt="AERIS Engineering Workspace"
            className="w-full h-auto"
          />

        </div>

      </motion.div>

    </div>

  </div>

</section>


	{/*What changes after AERIS is deployed. */}
{/* ENGINEERING OUTCOMES */}

<section id="outcomes" className="min-h-screen bg-white flex items-center">

  <div className="max-w-7xl mx-auto px-8 py-12">

    {/* HEADER */}

    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.7 }}
      className="text-center max-w-5xl mx-auto"
    >

      <div className="uppercase tracking-[0.3em] text-blue-600 mb-4">
        Engineering Outcomes
      </div>

      <h2 className={styles.sectionTitle}>
        Better Understanding.
		Better Investigation.
		Better Outcomes.
		</h2>

      <p className="mt-4 text-xl text-slate-600 leading-relaxed max-w-4xl mx-auto">
		AERIS establishes engineering understanding before review and investigation begin.
		This enables earlier insight, improved visibility and higher quality engineering outcomes.
      </p>

    </motion.div>

    {/* CONTENT */}

    <div className="mt-12 grid lg:grid-cols-[45%_55%] gap-8 items-center">

      {/* OUTCOMES */}

      <motion.div
        initial={{ opacity: 0, x: -40 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
      >

        <div className="space-y-8">

          <div className="flex items-center gap-4">
            <div className="w-3 h-3 rounded-full bg-blue-600" />
            <h3 className="text-2xl ">
              More Consistent Engineering Reviews
            </h3>
          </div>

          <div className="flex items-center gap-4">
            <div className="w-3 h-3 rounded-full bg-blue-600" />
            <h3 className="text-2xl ">
              Earlier Identification Of Engineering Risks
            </h3>
          </div>

          <div className="flex items-center gap-4">
            <div className="w-3 h-3 rounded-full bg-blue-600" />
            <h3 className="text-2xl ">
              Improved Lifecycle Visibility
            </h3>
          </div>

          <div className="flex items-center gap-4">
            <div className="w-3 h-3 rounded-full bg-blue-600" />
            <h3 className="text-2xl ">
              Reduced Manual Investigation Effort
            </h3>
          </div>

          <div className="flex items-center gap-4">
            <div className="w-3 h-3 rounded-full bg-blue-600" />
            <h3 className="text-2xl ">
            Better Prepared Review Activities
            </h3>
          </div>

        </div>

      </motion.div>
	  
	   {/* RIGHT */}

		<motion.div
		  initial={{ opacity: 0, x: 40 }}
		  whileInView={{ opacity: 1, x: 0 }}
		  viewport={{ once: true }}
		  transition={{ duration: 0.7 }}
		>

		  <div className="rounded-[32px] overflow-hidden border border-slate-200 shadow-xl">

			<Image
			  src={Aeris_Intelligence}
			  alt="AERIS Engineering Intelligence Outcomes"
			  className="w-full h-auto"
			/>

		  </div>
		  
		  <div className="mt-4 text-center text-sm text-slate-500">
  Engineering understanding → Investigation → Governed Intelligence → Review Outcomes
</div>

		</motion.div>

 </div>
 
 
		
    {/* FOOTER */}

    <motion.div
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.7 }}
      className="max-w-4xl mx-auto text-center mt-20"
    >

      <div className="uppercase tracking-[0.3em] text-blue-600 text-sm mb-4">
       Engineering Impact
      </div>

      <p className="text-xl text-slate-700 leading-relaxed">
        Engineering understanding provides the foundation for
		effective investigation. AERIS helps teams establish that
		understanding before decisions are made.
      </p>

    </motion.div>

  </div>

</section>

{/* FAQ / GOVERNANCE */}

<section
  id="faq"
  className="min-h-screen bg-slate-50 flex items-center"
>

  <div className="max-w-5xl mx-auto px-8 py-20">


{/* HEADER */}

<div className="text-center mb-14">

  <div className="uppercase tracking-[0.3em] text-blue-600 mb-5">
    Engineering AI Governance
  </div>

  <h2 className="text-4xl lg:text-5xl font-semibold text-slate-900">
    Built Around Human Authority.
  </h2>

  <p className="mt-6 text-lg text-slate-600 max-w-4xl mx-auto leading-relaxed">
    AERIS is designed for safety-critical engineering environments
    where governance, accountability, data control and human
    authority cannot be delegated to AI systems.
  </p>

</div>

{/* FAQS */}

<div className="space-y-4">

  {faqs.map((faq, index) => (

    <motion.div
      key={index}
      layout
      className="
        rounded-[24px]
        bg-white
        border
        border-slate-200
        overflow-hidden
        shadow-sm
      "
    >

      <button
        onClick={() =>
          setOpenFaq(
            openFaq === index ? null : index
          )
        }
        className="
          w-full
          flex
          items-center
          justify-between
          text-left
          px-8
          py-6
        "
      >

        <span className="text-lg font-medium text-slate-900">
          {faq.question}
        </span>

        <span
          className="
            text-2xl
            text-blue-600
            font-light
            ml-6
          "
        >
          {openFaq === index ? "−" : "+"}
        </span>

      </button>

      {openFaq === index && (

        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.25 }}
        >

          <div className="px-8 pb-8">

            <div className="border-t border-slate-100 pt-6">

              <p className="text-base text-slate-600 leading-8 max-w-4xl">
                {faq.answer}
              </p>

            </div>

          </div>

        </motion.div>

      )}

    </motion.div>

  ))}

</div>


  </div>

</section>


  {/* DIFFERENTIATORS */}

<section id ="why-aeris" className="py-24 bg-slate-950 text-white">

  <div className="max-w-7xl mx-auto px-8">


<h2 className={styles.sectionTitle}>
  Built For Safety-Critical Engineering
</h2>

<p className="text-xl text-slate-400 max-w-3xl mb-20">
  AERIS was designed to solve the AI adoption problem
  for safety-critical engineering environments.
</p>

<div className="grid lg:grid-cols-2 gap-8">

  {/* Card 1 */}

  <motion.div
    whileHover={{ scale: 1.03, y: -10 }}
    transition={{ duration: 0.3 }}
    className="group rounded-3xl border border-slate-800 p-10 bg-slate-900"
  >
    <h3 className="text-3xl font-semibold mb-4">
      Governed Intelligence
    </h3>

    <p className="text-slate-400">
      AI operating inside controlled engineering boundaries.
    </p>

    <div className="mt-8 opacity-0 max-h-0 overflow-hidden transition-all duration-500 group-hover:opacity-100 group-hover:max-h-96">

      <ul className="space-y-3 text-slate-300">

        <li>✓ Policy Enforcement</li>
        <li>✓ Controlled Scope</li>
        <li>✓ Audit Visibility</li>
        <li>✓ Review Boundaries</li>
        <li>✓ Lifecycle-Aware Operation</li>

      </ul>

    </div>

  </motion.div>

  {/* Card 2 */}

  <motion.div
    whileHover={{ scale: 1.03, y: -10 }}
    transition={{ duration: 0.3 }}
    className="group rounded-3xl border border-slate-800 p-10 bg-slate-900"
  >
    <h3 className="text-3xl font-semibold mb-4">
      Human Authority Preservation
    </h3>

    <p className="text-slate-400">
      Human initiates. AERIS analyzes. Human decides.
    </p>

    <div className="mt-8 opacity-0 max-h-0 overflow-hidden transition-all duration-500 group-hover:opacity-100 group-hover:max-h-96">

      <div className="space-y-4 text-slate-300">

        <div>Human Initiates</div>
        <div>↓</div>
        <div>AERIS Analyses</div>
        <div>↓</div>
        <div>Human Decides</div>

      </div>

    </div>

  </motion.div>

  {/* Card 3 */}

  <motion.div
    whileHover={{ scale: 1.03, y: -10 }}
    transition={{ duration: 0.3 }}
    className="group rounded-3xl border border-slate-800 p-10 bg-slate-900"
  >
    <h3 className="text-3xl font-semibold mb-4">
      Air-Gapped Deployment
    </h3>

    <p className="text-slate-400">
      Enterprise-controlled appliance deployment.
    </p>

    <div className="mt-8 opacity-0 max-h-0 overflow-hidden transition-all duration-500 group-hover:opacity-100 group-hover:max-h-96">

      <ul className="space-y-3 text-slate-300">

        <li>✓ Air-Gapped Operation</li>
        <li>✓ Local LLM Support</li>
        <li>✓ Enterprise Authentication</li>
        <li>✓ Audit Logging</li>
        <li>✓ Workspace Isolation</li>

      </ul>

    </div>

  </motion.div>

  {/* Card 4 */}

  <motion.div
    whileHover={{ scale: 1.03, y: -10 }}
    transition={{ duration: 0.3 }}
    className="group rounded-3xl border border-slate-800 p-10 bg-slate-900"
  >
    <h3 className="text-3xl font-semibold mb-4">
      Lifecycle Awareness
    </h3>

    <p className="text-slate-400">
      Engineering artifacts analyzed as a connected system.
    </p>

    <div className="mt-8 opacity-0 max-h-0 overflow-hidden transition-all duration-500 group-hover:opacity-100 group-hover:max-h-96">

      <div className="space-y-2 text-slate-300">

        <div>Requirements</div>
        <div>Design</div>
        <div>Code</div>
        <div>Verification</div>
        <div>Traceability</div>

      </div>

    </div>

  </motion.div>

</div>


  </div>

</section>


{/* EXPLORE AERIS */}

<section
  id="explore"
  className="min-h-screen bg-white flex items-center"
>

  <div className="max-w-7xl mx-auto px-8 py-20">


{/* HEADER */}

<div className="text-center max-w-4xl mx-auto mb-16">

  <div className="uppercase tracking-[0.3em] text-blue-600 mb-4">
    Explore AERIS
  </div>

<h2 className="
  text-xl
  lg:text-3xl
  font-semibold
  text-center
  tracking-tight
">
  Explore How AERIS Fits Into Your Engineering Environment.
</h2>

  <p className="mt-6 text-xl text-slate-600 leading-relaxed max-w-7xl mx-auto">
    Whether you are evaluating AI adoption,
    improving engineering review quality or exploring
    deployment within a safety-critical program,
    AERIS can operate within your existing engineering
    and governance environment.
  </p>

</div>

{/* CONTENT */}

<div className="grid lg:grid-cols-2 gap-20 items-start">

  {/* LEFT */}

  <motion.div
    initial={{ opacity: 0, x: -30 }}
    whileInView={{ opacity: 1, x: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.6 }}
    className="space-y-5"
  >

    <div className="rounded-3xl border border-slate-200 p-6">

      <div className="text-xl font-semibold mb-2">
        Human Authority
      </div>

      <p className="text-slate-600">
        Engineers remain responsible for all decisions,
        approvals and review outcomes.
      </p>

    </div>

    <div className="rounded-3xl border border-slate-200 p-6">

      <div className="text-xl font-semibold mb-2">
        Enterprise Control
      </div>

      <p className="text-slate-600">
        Deploy within enterprise-controlled
        infrastructure and security boundaries.
      </p>

    </div>

    <div className="rounded-3xl border border-slate-200 p-6">

      <div className="text-xl font-semibold mb-2">
        Air-Gapped Operation
      </div>

      <p className="text-slate-600">
        Supports isolated and offline deployment
        environments when required.
      </p>

    </div>

    <div className="rounded-3xl border border-slate-200 p-6">

      <div className="text-xl font-semibold mb-2">
        Governed Intelligence
      </div>

      <p className="text-slate-600">
        Architectural boundaries preserve
        accountability and governance.
      </p>

    </div>

  </motion.div>

  {/* RIGHT */}

  <motion.div
    initial={{ opacity: 0, x: 30 }}
    whileInView={{ opacity: 1, x: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.6 }}
  >

    <div className="rounded-[32px] bg-slate-50 border border-slate-200 p-8">

      <div className="text-2xl font-semibold text-slate-900 mb-6">
        Request Discussion
      </div>


		{submitted ? (

  <div className="py-10 text-center">

    <div className="text-5xl mb-6">
      ✓
    </div>

    <h3 className="text-2xl font-semibold text-green-700">
      Request Received
    </h3>

    <p className="mt-4 text-slate-600 leading-relaxed">
      Thank you for your interest in AERIS.
    </p>

    <p className="mt-2 text-slate-600 leading-relaxed">
      A member of our team will contact you shortly
		to discuss your engineering environment,
		governance requirements and deployment objectives.
    </p>

  </div>

) : (

  <form
    onSubmit={handleSubmit}
    className="space-y-4"
  >

    <input
      type="text"
      name="name"
      placeholder="Name"
      required
      value={formData.name}
      onChange={(e) =>
        setFormData({
          ...formData,
          name: e.target.value,
        })
      }
      className="
        w-full
        rounded-xl
        px-4
        py-3
        bg-white
        border
        border-slate-200
      "
    />

    <input
      type="text"
      name="organization"
      placeholder="Organization"
      required
      value={formData.organization}
      onChange={(e) =>
        setFormData({
          ...formData,
          organization: e.target.value,
        })
      }
      className="
        w-full
        rounded-xl
        px-4
        py-3
        bg-white
        border
        border-slate-200
      "
    />

    <input
      type="email"
      name="email"
      placeholder="Business Email"
      required
      value={formData.email}
      onChange={(e) =>
        setFormData({
          ...formData,
          email: e.target.value,
        })
      }
      className="
        w-full
        rounded-xl
        px-4
        py-3
        bg-white
        border
        border-slate-200
      "
    />

    <textarea
      rows={4}
      name="message"
      placeholder="Tell us about your objectives or environment."
      required
      value={formData.message}
      onChange={(e) =>
        setFormData({
          ...formData,
          message: e.target.value,
        })
      }
      className="
        w-full
        rounded-xl
        px-4
        py-3
        bg-white
        border
        border-slate-200
      "
    />

    <button
      type="submit"
      disabled={loading}
      className="
        mt-2
        px-8
        py-4
        rounded-full
        bg-blue-600
        text-white
        hover:bg-blue-700
        transition
      "
    >
      {loading
        ? "Submitting..."
        : "Discuss AERIS"}
    </button>

    <p className="text-sm text-slate-500 leading-relaxed">
      We use these details only to respond to your request. Please do not
      include confidential or export-controlled information. See our{" "}
      <Link href="/privacy" className="text-blue-600 underline underline-offset-4">
        Privacy Policy
      </Link>
      .
    </p>

  </form>

)}
			
			
    </div>

  </motion.div>

</div>


  </div>

</section>


</main>

<SiteFooter />

</>
);
}
