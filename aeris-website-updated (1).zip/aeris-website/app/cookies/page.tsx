import type { Metadata } from "next";
import Link from "next/link";
import LegalPage from "@/components/LegalPage";
import ContactEmail from "@/components/ContactEmail";

export const metadata: Metadata = {
  title: "Cookie Notice",
  description: "Which cookies and similar technologies the AERIS website uses.",
  alternates: { canonical: "/cookies" },
};

export default function CookiesPage() {
  return (
    <LegalPage
      title="Cookie Notice"
      summary="This notice explains how the AERIS website uses cookies and similar technologies. The short version: we do not use analytics, advertising or tracking cookies."
    >
      <h2>What cookies are</h2>
      <p>
        Cookies are small text files a website stores in your browser. Similar technologies
        include local storage and tracking pixels. They can be used to make a site work, to
        measure how it is used or to track visitors for advertising.
      </p>

      <h2>What this website uses</h2>
      <p>
        The AERIS website does not set analytics, advertising or social media cookies, and
        it does not use tracking pixels. We do not track you across other websites.
      </p>
      <p>
        Our hosting provider may use technical data or strictly necessary cookies that are
        needed to deliver the pages securely and reliably. These do not identify you for
        marketing purposes, and the website cannot work properly without them, so they do
        not require consent.
      </p>
      <p>
        The website&apos;s fonts are served from our own domain, so loading a page does not
        send a request to a third-party font service.
      </p>

      <h2>If this changes</h2>
      <p>
        If we add analytics or any other non-essential cookies in the future, we will update
        this notice first and, where the law requires it, ask for your consent before those
        cookies are set.
      </p>

      <h2>Managing cookies</h2>
      <p>
        You can block or delete cookies in your browser settings. Blocking strictly
        necessary cookies may affect how the website works.
      </p>

      <h2>More information</h2>
      <p>
        Our <Link href="/privacy">Privacy Policy</Link> explains how we handle personal
        information. Questions about this notice can be sent to <ContactEmail />.
      </p>
    </LegalPage>
  );
}
