import Link from "next/link";
import { site, isPlaceholder } from "@/lib/site";

const legalLinks = [
  { href: "/privacy", label: "Privacy Policy" },
  { href: "/terms", label: "Terms of Use" },
  { href: "/cookies", label: "Cookie Notice" },
  { href: "/legal", label: "IP and Trademarks" },
  { href: "/disclaimer", label: "Product Disclaimer" },
];

export default function SiteFooter() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-slate-950 text-slate-300">
      <div className="max-w-7xl mx-auto px-8 py-16">
        <div className="grid gap-12 md:grid-cols-3">
          <div>
            <Link href="/" className="flex flex-col leading-none text-white">
              <span className="text-2xl font-semibold tracking-wide">AERIS</span>
              <span className="text-xs text-slate-400 tracking-[0.15em] mt-1">
                Governed Intelligence System
              </span>
            </Link>

            <p className="mt-6 text-sm leading-relaxed text-slate-400 max-w-xs">
              AERIS is a product of{" "}
              <a
                href={site.companyUrl}
                target="_blank"
                rel="noopener"
                className="text-white underline underline-offset-4 hover:text-blue-300"
              >
                {site.companyName}
              </a>
            </p>
          </div>

          <div>
            <h2 className="text-sm font-semibold text-white">Company</h2>
            <address className="mt-4 not-italic text-sm leading-relaxed text-slate-400">
              {site.companyName}
              <br />
              {site.companyStreet}
              <br />
              {site.companyCity}
              <br />
              {site.companyCountry}
              <br />
              {isPlaceholder(site.contactEmail) ? (
                <span>{site.contactEmail}</span>
              ) : (
                <a
                  href={`mailto:${site.contactEmail}`}
                  className="hover:text-white underline underline-offset-4"
                >
                  {site.contactEmail}
                </a>
              )}
            </address>
          </div>

          <div>
            <h2 className="text-sm font-semibold text-white">Legal</h2>
            <ul className="mt-4 space-y-2 text-sm">
              {legalLinks.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-slate-400 hover:text-white">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-14 border-t border-slate-800 pt-8 text-xs leading-relaxed text-slate-500 space-y-3">
          <p>
            AERIS supports engineering teams. It does not certify compliance, approve
            engineering work or replace the judgment of qualified engineers.{" "}
            <Link href="/disclaimer" className="underline underline-offset-4 hover:text-slate-300">
              Read the product disclaimer
            </Link>
            .
          </p>
          <p>
            © {year} {site.companyName} All rights reserved. AERIS and the AERIS logo are
            trademarks of {site.companyName}
          </p>
        </div>
      </div>
    </footer>
  );
}
