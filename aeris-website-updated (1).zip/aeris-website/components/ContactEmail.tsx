import { site, isPlaceholder } from "@/lib/site";

export default function ContactEmail() {
  if (isPlaceholder(site.contactEmail)) {
    return <span>{site.contactEmail}</span>;
  }
  return <a href={`mailto:${site.contactEmail}`}>{site.contactEmail}</a>;
}
