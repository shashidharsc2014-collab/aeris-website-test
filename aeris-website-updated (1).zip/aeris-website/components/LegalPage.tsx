import Link from "next/link";
import SiteFooter from "@/components/SiteFooter";
import { site } from "@/lib/site";

type LegalPageProps = {
  title: string;
  summary: string;
  children: React.ReactNode;
};

export default function LegalPage({ title, summary, children }: LegalPageProps) {
  return (
    <>
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-xl border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 md:px-8 h-20 flex items-center gap-4">
          <Link href="/" className="flex flex-col leading-none">
            <span className="text-2xl font-semibold tracking-wide">AERIS</span>
            <span className="text-xs text-slate-500 tracking-[0.15em] mt-1">
              Governed Intelligence System
            </span>
          </Link>

          <Link
            href="/#explore"
            className="ml-auto shrink-0 whitespace-nowrap px-4 py-2 text-sm md:px-6 md:py-3 md:text-base rounded-full bg-blue-600 text-white font-medium hover:bg-blue-700 transition"
          >
            Discuss AERIS
          </Link>
        </div>
      </header>

      <main className="bg-white text-slate-900 flex-1">
        <div className="max-w-3xl mx-auto px-8 py-20">
          <Link href="/" className="text-sm text-blue-600 hover:text-blue-700">
            Back to home
          </Link>

          <h1 className="mt-6 text-4xl md:text-5xl font-semibold leading-tight tracking-tight">
            {title}
          </h1>

          <p className="mt-4 text-sm text-slate-500">
            Effective {site.legalEffectiveDate}
          </p>

          <p className="mt-8 text-lg text-slate-600 leading-relaxed">{summary}</p>

          <div
            className="
              mt-12 text-slate-700 leading-relaxed
              [&_h2]:mt-12 [&_h2]:text-2xl [&_h2]:font-semibold [&_h2]:text-slate-900
              [&_h3]:mt-8 [&_h3]:text-lg [&_h3]:font-semibold [&_h3]:text-slate-900
              [&_p]:mt-4
              [&_ul]:mt-4 [&_ul]:list-disc [&_ul]:pl-6 [&_ul]:space-y-2
              [&_a]:text-blue-600 [&_a]:underline [&_a]:underline-offset-4 hover:[&_a]:text-blue-700
            "
          >
            {children}
          </div>
        </div>
      </main>

      <SiteFooter />
    </>
  );
}
